/*
 * LCD16x2.h
 *
 *  Created on: 23 jun. 2021
 *      Author: Personal
 */

#ifndef LCD16X2_H_
#define LCD16X2_H_

extern void DPY_vfnDriverInit (void);

#endif /* LCD16X2_H_ */
