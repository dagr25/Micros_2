/*
 * adc.h
 *
 *  Created on: 24 jun. 2021
 *      Author: Personal
 */

#ifndef ADC_H_
#define ADC_H_

extern void ADC_vfnDriverInit ( void );

extern unsigned short ADC_bfnReadADC(unsigned char channelNumber);


#endif /* ADC_H_ */
