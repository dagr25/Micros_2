/*
 * pinSetting.h
 *
 *  Created on: 19 nov. 2020
*/

#ifndef PINSETTING_H_
#define PINSETTING_H_

extern void pinMode(char puerto1, int numeropin1, int GPIO1);
extern void digitalWrite(char puerto2, int numeropin2, int GPIO2);
extern int digitalRead(char puerto3, int numeropin3);

#endif
